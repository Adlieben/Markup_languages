# Developer portfolio

Here is the link to the website created by this project: http://www.adammaghout-academic.com/
